This distribution provides a variety of access control middlewares.
Convenience functions which can be used as decorators are included.
The classes have useful defaults yet are highly configurable. 
All interfaces are designed to be easily customized and extended.
Currently supports HTTP Basic and Web forms authentication, 
roles-based authorization and is beaker session compatible out of
the box. (It is no problem to use some other type of sessions or none.)

